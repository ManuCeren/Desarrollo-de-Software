
package Interfaces;

import Modelo.Departamento;
import java.util.List;

public interface CRUDDepartamento {
    public List<Departamento> listar();

}
