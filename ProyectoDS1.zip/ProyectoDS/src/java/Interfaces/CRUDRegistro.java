
package Interfaces;

import Modelo.RegistroLlamadas;
import java.util.List;

public interface CRUDRegistro {
    public boolean agregar(RegistroLlamadas registro);
    public List<RegistroLlamadas> listar();
    

}
