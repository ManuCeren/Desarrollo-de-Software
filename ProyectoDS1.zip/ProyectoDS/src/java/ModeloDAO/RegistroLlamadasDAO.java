
package ModeloDAO;

import Config.Conexion;
import Modelo.RegistroLlamadas;
import Interfaces.CRUDRegistro;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;

public class RegistroLlamadasDAO implements CRUDRegistro{
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;

    // Crear un registro de llamada
    @Override
    public boolean agregar(RegistroLlamadas registro) {
        String sql = "INSERT INTO registroLlamadas (fecha_Hora_Llamada, hora_Inicio, hora_Final, motivoLlamada, solucion, estado, id_Cliente, id_Agente, id_Categoria) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setTimestamp(1, new java.sql.Timestamp(registro.getFechaHoraLlamada().getTime()));
            ps.setTime(2, Time.valueOf(registro.getHoraInicio().toString()));
            ps.setTime(3, Time.valueOf(registro.getHoraFinal().toString()));
            ps.setString(4, registro.getMotivoLlamada());
            ps.setString(5, registro.getSolucion());
            ps.setString(6, registro.getEstado());
            ps.setInt(7, registro.getIdCliente());
            ps.setInt(8, registro.getIdAgente());
            ps.setInt(9, registro.getIdCategoria());
            ps.executeUpdate();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // Leer todos los registros
    @Override
    public List<RegistroLlamadas> listar() {
        List<RegistroLlamadas> lista = new ArrayList<>();
        String sql = "SELECT * FROM registroLlamadas";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                RegistroLlamadas reg = new RegistroLlamadas();
                reg.setIdLlamada(rs.getInt("id_Llamada"));
                reg.setFechaHoraLlamada(rs.getTimestamp("fecha_Hora_Llamada"));
                reg.setHoraInicio(rs.getTime("hora_Inicio"));
                reg.setHoraFinal(rs.getTime("hora_Final"));
                reg.setMotivoLlamada(rs.getString("motivoLlamada"));
                reg.setSolucion(rs.getString("solucion"));
                reg.setEstado(rs.getString("estado"));
                reg.setIdCliente(rs.getInt("id_Cliente"));
                reg.setIdAgente(rs.getInt("id_Agente"));
                reg.setIdCategoria(rs.getInt("id_Categoria"));
                lista.add(reg);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }
}

